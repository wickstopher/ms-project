#! /usr/bin/env bash

# Install the necessary libraries
cd tx-events
make install
cd ..
cd tehstomp-lib
make install
