This is a slightly modified version of the tx-events library (original source at https://cs.rit.edu/~mtf/research/tx-events/index.html).
It has been minimally modified to compile against ghc version 7.10.3
