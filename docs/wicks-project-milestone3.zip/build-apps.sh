#! /usr/bin/env bash

# Builds the client and server applications
cd tehstomp-server
make build
cd ..
ln -s tehstomp-server/StompBroker broker
cd tehstomp-client
make
cd ..
ln -s tehstomp-client/StompClient client
